The forcing.csv files are numerical rewrites of the corresponding annual subsets below. Concentrations are serialized with enough digits to reproduce the model's double values. These concentration snapshots retain the source attribution and CC BY-SA 4.0 license.

# 年平均大气 CO₂ 浓度

这三个 CSV 是 Nicholls 与 Lewis 发布的 RCMIP v5.1.0 协议数据的子集，以 CC BY-SA 4.0 分发。数据处理仅涉及筛选情景、截取年份、转置年列及重命名列头。原始浓度的十进制文本完整保留，单位为 ppm。 [RCMIP v5.1.0（DOI 10.5281/zenodo.4589756）](https://doi.org/10.5281/zenodo.4589756) · [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/)

| 文件 | `Scenario` | `Model` | 年份（含首尾） |
| --- | --- | --- | --- |
| `historical-co2.csv` | `historical` | `unspecified` | 1850–2014 |
| `ssp245-co2.csv` | `ssp245` | `MESSAGE-GLOBIOM` | 1850–2100 |
| `ssp585-co2.csv` | `ssp585` | `REMIND-MAGPIE` | 1850–2100 |

三条序列均筛选 `Region=World`、`Variable=Atmospheric Concentrations|CO2`、`Unit=ppm`、`Activity_Id=input4MIPs` 和 `Mip_Era=CMIP6`。SSP 序列在 1850–2014 年与历史序列逐年一致。DAOSHU 0D EBM 在每一模拟年内固定使用该年给出的浓度，并用本模式的对数公式换算 CO₂ 辐射强迫。历史与 SSP 案例仅施加 CO₂ 浓度变化。

## 重现提取

在仓库根目录执行以下命令。提取脚本需要 Python 3.9 或更新版本，运行时检查原始文件的 SHA-256，并逐年比较三个历史片段。默认写回本目录，可通过 `--output-dir` 指定另一个输出目录。

```bash
curl -fL https://zenodo.org/records/4589756/files/rcmip-concentrations-annual-means-v5-1-0.csv \
  -o /tmp/rcmip-concentrations-annual-means-v5-1-0.csv
python3 tools/extract_rcmip_co2.py /tmp/rcmip-concentrations-annual-means-v5-1-0.csv \
  --output-dir /tmp/daoshu-forcing
```

原始文件在 Zenodo 公布的 MD5 为 `0d82c3c3cdd4dd632b2bb9449a5c315f`。各文件的 SHA-256 如下。

| 文件 | SHA-256 |
| --- | --- |
| `rcmip-concentrations-annual-means-v5-1-0.csv` | `b6749ea32cc36eb0badc5d028b5b7b7bbcc56606144155fa2c0c3f9ceeac18c9` |
| `historical-co2.csv` | `24cc9f098427b255ac44a973f56fe9dfb7734c2d9c9f6cb5d807780f7ac44316` |
| `ssp245-co2.csv` | `1ff4293e4d0fa05c89d383efb49ae6df1922a1820f063684b7852da45e746483` |
| `ssp585-co2.csv` | `f75c11804f356285148b979a793232fa6f424dda45047e0dbf311a45267dd459` |

## 引用

- Nicholls、Lewis（2021），RCMIP v5.1.0 协议数据与再分发来源。[Zenodo](https://doi.org/10.5281/zenodo.4589756)
- Nicholls 等（2020），RCMIP 第一期协议与全球平均温度响应评估。[Geoscientific Model Development](https://doi.org/10.5194/gmd-13-5175-2020)
- Meinshausen 等（2017），CMIP6 历史温室气体浓度。[Geoscientific Model Development](https://doi.org/10.5194/gmd-10-2057-2017)
- Meinshausen 等（2020），SSP 温室气体浓度与延伸情景。[Geoscientific Model Development](https://doi.org/10.5194/gmd-13-3571-2020)
